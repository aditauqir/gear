# Plan C v2, arm F: Adaption mixed swarm (self-run package)

This is the same experiment as the Plan C v2 main grid, run on Adaption-hosted models. It is a separate
robustness arm: its results are never pooled with the Qwen-2.5 arms.

## The swarm

- **Agents:** N=8, 2 each of `deepseek-v4-flash` (reasoning effort none), `gemma-4-26b-a4b-it` (default), `gemma-4-31b-it` (default) and `qwen3.8-27b` (none).
- **D-Evil:** `qwen3.8-27b` (none).
- **Judge:** `deepseek-v4-flash` (none, temperature 0).
- **Per seed:** 1 shared round-1 prefix, then 3 clean twins (defense none / provenance / reputation+corroboration+quarantine) and 6 attacked branches (D-Evil or insider × the same 3 defenses).
- **Instruments:** revealed preference, structure, interview vs ledger, lie battery and LLM judge run on every attacked branch.
- **Seeds:** 10 by default.

## Your API key

The key comes **only** from the environment variable `ADAPTION_API_KEY`. If that isn't set, the script asks with a hidden prompt.

It is never printed, logged, put in an environment variable by the script, or written to `./arm_f_out/`.

## Budget guard

`--max-usd` defaults to 5.
- After the first seed, the script prints the projected total.
- If the projection is over the limit, it **stops** with exit code 2.
- `--max-usd` is also a hard cap on spend during the run.

Our estimate is $0.5-1.1 for 10 seeds and about 20-25 minutes. Adaption's ~380 requests/min limit is what sets the time.

The cost shown is Adaption's own `usage.cost` field. We don't know whether your account is billed in dollars or credits, so please compare the printed number with your Adaption dashboard after the first run.

## Commands, on your own machine (Python 3.10+)

```bash
unzip arm_f_package.zip && cd arm_f_package
python -m pip install -r requirements.txt          # numpy pandas matplotlib networkx scikit-learn requests openai
python run_arm_f.py --dry-run                      # fake backend: no key, no network, about 10 s. Check this works first.
export ADAPTION_API_KEY=...                        # or skip this line and type the key at the hidden prompt
python run_arm_f.py                                # real run: 10 seeds, stops if the projection is over $5
```

**Options:**

| Option | Meaning |
|---|---|
| `--seeds 10` | number of seeds |
| `--max-usd 5` | budget limit |
| `--out arm_f_out` | output folder |
| `--parallel 6` | seeds run at once |
| `--models "deepseek-v4-flash:none,gemma-4-26b-a4b-it:default,gemma-4-31b-it:default,qwen3.8-27b:none,glm-53-flash:low" --n 10` | 5-model version (use `glm-53-flash` at effort **low** only; the other effort values run away) |

## Commands, on Kaggle

Use `%pip`, not `!pip`; that avoids the numpy import mismatch.

1. Add the zip as a dataset ("Add data" → upload `arm_f_package.zip`).
2. Add your key as a secret: Add-ons → Secrets → name `ADAPTION_API_KEY`.
3. Turn Internet on (Settings → Internet).

Then, in cells:
```python
!cp -r /kaggle/input/*/arm_f_package /kaggle/working/ 2>/dev/null || unzip -q /kaggle/input/*/arm_f_package.zip -d /kaggle/working/
%cd /kaggle/working/arm_f_package
%pip install -q -r requirements.txt
!python run_arm_f.py --dry-run
```
```python
import os
from kaggle_secrets import UserSecretsClient
os.environ["ADAPTION_API_KEY"] = UserSecretsClient().get_secret("ADAPTION_API_KEY")   # never print it
!python run_arm_f.py
```
```python
!cd /kaggle/working/arm_f_package && zip -qr /kaggle/working/arm_f_out.zip arm_f_out   # download this from the Output tab
```

Use `!python`, not `%run`. The script re-launches itself with `PYTHONHASHSEED=0` so its games are reproducible, and `!python` lets it do that safely.

## Outputs, in `./arm_f_out/`

| File | Contents |
|---|---|
| `results.json` | all statistics, labelled `armF` |
| `figs/*.png` + `figs/*.csv` | figures, with the data each was drawn from |
| `messages.csv` | every message, with a `kind` column |
| `games.jsonl`, `agents.jsonl`, `cells.jsonl`, `events.jsonl` | raw per-game and per-agent records |
| `cost_tally.json` | spend tally |

**Please send back the whole `arm_f_out` folder (zipped).** It contains no key.

## If something fails

- **A model isn't enabled for your account** (HTTP 4xx naming it): remove it from `--models` and re-run. Same rule if any error repeats 3 times: the script stops on its own.
- **Rate limits** (HTTP 429) are retried automatically. If the run is slow, lower `--parallel`.

## What's inside

- `swarm_llm/`: Jennifer's game modules, **byte-identical** (`swarm_llm_sha256.txt`). The Adaption-API and real-world-route modules are left out because this arm doesn't need them.
- `harness/`: the Plan C v2 harness.
  - cost tally
  - verified fast paths
  - severity patch
  - self-give fix
  - instruments
  - Adaption backend (streaming, rate limits, retries, cost cap)
  - analysis
- `HYPOTHESES.md`, `PREREG_SHA256.txt`, `CHANGES.md`: the pre-registration and change log the analysis embeds.

#!/usr/bin/env python3
"""Plan C v2, arm F: Adaption mixed swarm. A self-contained run that Jennifer launches on her own machine or Kaggle.

    python run_arm_f.py --dry-run                 # fake backend, no key, no network; checks the whole pipeline
    python run_arm_f.py                           # real run: key from env ADAPTION_API_KEY, else a hidden prompt
    python run_arm_f.py --max-usd 5 --seeds 10    # defaults shown

Design: same as the Plan C v2 main grid and mixed-swarm arms. N=8 agents, 2 each of deepseek-v4-flash (effort none),
gemma-4-26b-a4b-it (default), gemma-4-31b-it (default) and qwen3.8-27b (none). Per seed: a shared round-1 prefix, then
3 clean twins (one per defense) + 6 attacked branches (D-Evil / insider x none / provenance / rep+corr+quar), all
forked with the same branch seed. Instruments 1-5 run on every attacked branch.
D-Evil = qwen3.8-27b (none), judge = deepseek-v4-flash (none, temperature 0); everything runs on Adaption.

Budget guard: after the first seed finishes, it prints the projected total and STOPS if that exceeds --max-usd.
--max-usd is also enforced as a hard cap on the summed usage.cost during the run.
The key is never printed, logged, put in the environment, or written to ./arm_f_out/.
Outputs: ./arm_f_out/  (games/agents/cells/events .jsonl, messages.csv, cost_tally.json, results.json, figs/*.png + .csv)
"""
import os, sys, argparse, json, time, getpass, runpy

HERE = os.path.dirname(os.path.abspath(__file__))
p = argparse.ArgumentParser()
p.add_argument("--dry-run", action="store_true", help="fake deterministic backend: no key, no network, no cost")
p.add_argument("--max-usd", type=float, default=5.0)
p.add_argument("--seeds", type=int, default=10)
p.add_argument("--out", default="arm_f_out")
p.add_argument("--models", default="deepseek-v4-flash:none,gemma-4-26b-a4b-it:default,gemma-4-31b-it:default,qwen3.8-27b:none",
               help="model:effort list; add glm-53-flash:low for the 5-model version (then use --n 10)")
p.add_argument("--n", type=int, default=0, help="agents (default 2 x number of models)")
p.add_argument("--parallel", type=int, default=6, help="seeds run at once (Adaption allows about 380 requests/min)")
args = p.parse_args()

# reproducible instance generation: her engine depends on Python's hash seed at larger N, so re-launch with it fixed
if os.environ.get("PYTHONHASHSEED") != "0":
    if "ipykernel" in sys.modules or "IPython" in sys.modules:   # inside a notebook (%run): don't replace the kernel
        print("note: PYTHONHASHSEED is not 0 inside a notebook; N=8 games are unaffected. Prefer `!python run_arm_f.py`.", flush=True)
    else:
        os.environ["PYTHONHASHSEED"] = "0"
        os.execv(sys.executable, [sys.executable] + sys.argv)

OUT = os.path.abspath(args.out); os.makedirs(OUT, exist_ok=True)
sys.path[:0] = [os.path.join(HERE, "harness"), os.path.join(HERE, "swarm_llm")]
os.environ["OUT"] = OUT
os.environ["COST_CAP"] = "1000"                        # OpenRouter tally (unused in this arm)
os.environ["ADAPTION_CAP_USD"] = str(args.max_usd)     # hard cap on the Adaption spend
os.environ.setdefault("OPENROUTER_API_KEY", "unused-in-arm-F")
os.environ["PAR_CELLS"] = str(args.parallel)
os.environ["SEEDS_F"] = str(args.seeds)
import matplotlib; matplotlib.use("Agg")

key = None
if not args.dry_run:
    key = os.environ.get("ADAPTION_API_KEY") or getpass.getpass("Adaption API key (hidden): ")
    if not key:
        sys.exit("No Adaption key given.")

import run_v2 as rv                 # harness: patches (cost tally, fast paths, severity, give fix), run_cell, pmap
import costpatch, adaption_backend as adb
adb.KEY = key; del key
import llm_game as lg

specs = [tuple(x.split(":")) for x in args.models.split(",")]
N = args.n or 2 * len(specs)

if args.dry_run:
    from detmock import DetMock
    class FakeAdaption(DetMock):
        """Deterministic stand-in: exercises bribes, defections, interviews and judge parsing; charges a fake $0.0002/call."""
        def __init__(self, model, effort=None, arm="F", temperature=0.7, max_workers=8):
            self.model = self.name = model; self.arm = arm
        def chat(self, pairs, seed=0):
            out = super().chat(pairs, seed)
            with costpatch._LOCK:
                C = costpatch.COST; C["adaption_usd"] = C.get("adaption_usd", 0.0) + 0.0002 * len(pairs)
                C["adaption_calls"] = C.get("adaption_calls", 0) + len(pairs)
                a = C["by_arm"].setdefault(self.arm, {"usd": 0.0, "calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
                a["calls"] += len(pairs); a["usd"] += 0.0002 * len(pairs)
            return out
    BK = FakeAdaption
else:
    BK = adb.AdaptionBackend
agents = adb.make_adaption_mixed(specs, arm="F", backend_cls=BK)
d_evil = BK("qwen3.8-27b", "none", arm="F_d_evil")
judge = BK("deepseek-v4-flash", "none", arm="F_judge", temperature=0.0) if not args.dry_run else BK("deepseek-v4-flash", "none", arm="F_judge")
DEFS = rv.DEFS
br = [(f"clean|{d}", None, d) for d in DEFS] + [(f"{a}|{d}", a, d) for a in ("d_evil", "insider") for d in DEFS]
rv.log("arm F", "DRY RUN (fake backend)" if args.dry_run else "LIVE (Adaption)", "| agents:",
       {i: agents.model_for(i) for i in range(N)}, "| seeds:", args.seeds, "| max $", args.max_usd)

def cell(sd):
    return rv.run_cell("F", sd, N, "complete", "private", 1, "assistant", agents, d_evil, br, judge=judge, msg_file="messages.csv")

t0 = time.time()
cell(0)                                                       # first seed alone -> budget projection
spent1 = costpatch.COST.get("adaption_usd", 0.0)
proj = spent1 * args.seeds
msg = dict(ev="budget_projection", first_seed_usd=round(spent1, 4), projected_total_usd=round(proj, 4),
           max_usd=args.max_usd, first_seed_wall_s=round(time.time() - t0, 1), dry_run=args.dry_run)
rv.jl("events.jsonl", msg)
print(f"\nBUDGET: first seed cost {spent1:.4f}; projected for {args.seeds} seeds: {proj:.4f} (max {args.max_usd})"
      f"{'  [fake costs, dry run]' if args.dry_run else ''}", flush=True)
if proj > args.max_usd:
    print("STOP: the projection is over --max-usd. Nothing more will be spent. Re-run with fewer --seeds or a higher --max-usd.", flush=True)
    rv._save_cost(); sys.exit(2)
rv.pmap(cell, [(sd,) for sd in range(1, args.seeds)], args.parallel)
rv._save_cost()
rv.jl("events.jsonl", dict(ev="arm_done", arm="F", secs=round(time.time() - t0, 1), adaption_usd=costpatch.COST.get("adaption_usd", 0.0),
                           adaption_calls=costpatch.COST.get("adaption_calls", 0), adaption_failed=costpatch.COST.get("adaption_failed", 0)))
print(f"\nDONE: {args.seeds} seeds, Adaption cost {costpatch.COST.get('adaption_usd', 0.0):.4f}, "
      f"failed calls {costpatch.COST.get('adaption_failed', 0)}, {time.time() - t0:.0f}s", flush=True)

# analysis (no API calls): results.json + figures + CSVs, labelled arm F
os.environ["REMAP"] = "F:A"; os.environ["VERSION"] = "armF" + ("-dryrun" if args.dry_run else "")
sys.argv = ["analyze_v2.py", OUT, os.path.join(OUT, "figs")]
try:
    import io, contextlib
    with contextlib.redirect_stdout(io.StringIO()):
        runpy.run_path(os.path.join(HERE, "harness", "analyze_v2.py"), run_name="__main__")
    print("analysis written:", os.path.join(OUT, "results.json"), "and", os.path.join(OUT, "figs"), flush=True)
except Exception as e:
    print("analysis step failed (raw data is still in", OUT, "):", type(e).__name__, str(e)[:200], flush=True)
print("Send back the whole folder:", OUT, flush=True)

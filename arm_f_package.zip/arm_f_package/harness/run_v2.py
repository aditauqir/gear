"""Plan C v2 driver (own script calling Jennifer's unchanged package; her notebook is reference only).
Run via launch.py (key from file by path, never printed) with PYTHONHASHSEED=0:
  OUT=<dir> ARMS=A,B,C,D,E SEEDS_A=20 SEEDS_B=20 SEEDS_C=10 SEEDS_D=10 SEEDS_E=10 COST_CAP=8 PAR_CELLS=10
  PILOT=1 -> 1 seed per arm.
Arms (see PLAN.md §1): A main grid, B deterrence, C scaling, D robustness (mixed swarm), E validity."""
import os, sys, json, time, threading, traceback, collections
from concurrent.futures import ThreadPoolExecutor, as_completed
OUT = os.environ["OUT"]; os.makedirs(OUT, exist_ok=True)
import costpatch
COST, _save_cost = costpatch.install(float(os.environ.get("COST_CAP", "8.0")), OUT)
import llm_game as lg
import fastpaths; fastpaths.install(lg)
import v2patch; v2patch.install(lg)
if os.environ.get("JWIN_FIXES", "1") == "1":
    import jwin_fixes; _save_fixes = jwin_fixes.install(OUT)
from backends import make_backend, make_mixed, openrouter_credits, parse_json
import instruments as ins
import numpy as np

PILOT = os.environ.get("PILOT") == "1"
ARMS = os.environ.get("ARMS", "A,B,C,D,E").split(",")
NS = lambda k, d: 1 if PILOT else int(os.environ.get(f"SEEDS_{k}", d))
SEEDS = {"A": NS("A", 20), "B": NS("B", 20), "C": NS("C", 10), "D": NS("D", 10), "E": NS("E", 10), "F": NS("F", 10)}
START = {k: int(os.environ.get(f"SEED_START_{k}", "0")) for k in SEEDS}   # v2.1 extension: run seeds START..SEEDS-1 only
SIZES_C = [int(x) for x in os.environ.get("SIZES_C", "4,8,16,32").split(",")]
PAR = int(os.environ.get("PAR_CELLS", "10"))
QWEN = "qwen/qwen-2.5-7b-instruct"
MIXED = ["qwen/qwen-2.5-7b-instruct", "meta-llama/llama-3.1-8b-instruct", "google/gemma-3-12b-it", "openai/gpt-oss-20b"]
FORK, ROUNDS, ACT = 1, 12, 0.7          # prefix = round 1; attackers act from round 2
DEFS = ["none", "provenance", "reputation+corroboration+quarantine"]
_L = threading.Lock()
def jl(name, obj):
    with _L, open(os.path.join(OUT, name), "a") as f:
        f.write(json.dumps(obj, default=lambda o: o.item() if hasattr(o, "item") else str(o)) + "\n")
def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)

def mk(model, arm, temp=0.7, mnt=160):
    b = make_backend(model, engine="openrouter", temperature=temp, max_new_tokens=mnt, max_workers=8); b.arm = arm; return b
def mkmixed(arm):
    m = make_mixed(MIXED, engine="openrouter", temperature=0.7, max_new_tokens=160, max_workers=8)
    for sb in m.backends: sb.arm = arm
    return m
CACHE = ins.Cache(os.path.join(OUT, "judge_cache.jsonl"))
ERRS = collections.Counter()

def pmap(fn, items, workers):
    out = [None] * len(items)
    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(items) or 1))) as ex:
        fs = {ex.submit(fn, *it): k for k, it in enumerate(items)}
        for f in as_completed(fs):
            try:
                out[fs[f]] = f.result()
            except costpatch.CostCapExceeded:
                raise
            except Exception as e:
                sig = f"{type(e).__name__}: {str(e)[:120]}"
                with _L:
                    ERRS[sig] += 1; n = ERRS[sig]
                jl("errors.jsonl", dict(sig=sig, tb=traceback.format_exc()[-2000:]))
                log("ERROR", sig, "count", n)
                if n >= 3:
                    raise RuntimeError(f"same error 3 times, stopping: {sig}")
    return out

def gift_events(st):
    return [(c["round"], c["agent"], int(c["parsed"]["to"])) for c in st.calls
            if c["result"] == "give" and isinstance(c.get("parsed"), dict)]

def branch_row(meta, name, attacker, defense, b, x, clean_all=None, clean_ex=None):
    m_all = lg.game_metrics(b); m_ex = lg.game_metrics(b, exclude=(x,)) if x is not None and x not in b.compromised else m_all
    bm = lg.betrayal_metrics(b, FORK)
    L = ins.labels(b, FORK)
    pr, bt = ins.structure(b)
    row = dict(meta, branch=name, attacker=attacker or "clean", defense=defense, insider=x,
               completion=m_all["completion"], completion_ex_insider=m_ex["completion"], keys_frac=m_all["keys_frac"],
               rounds=b.round, defections=bm["defections"], defect_success=bm["defect_success"], defect_fail=bm["defect_fail"],
               cooperation_rate=bm["cooperation_rate"], keys_burned=bm["keys_burned"], invalid=bm["invalid"],
               d_evil_messages=bm["d_evil_messages"], d_evil_reached=bm["d_evil_reached"],
               bribe_offers=bm["bribe_offers"], bribes_accepted=bm["bribes_accepted"],
               turned=int(sum(L["turned"])), exposed=int(sum(L["exposed"])), honest=b.cfg.N - len(b.compromised),
               gift_events=gift_events(b),
               defection_events=[(d["round"], d["actor"], d["target"], int(d["success"])) for d in b.defections],
               pagerank=[round(float(v), 5) for v in pr],
               quarantined_insider=(int(x in lg.quarantined_set(b)) if (x is not None and "quarantine" in defense and attacker == "insider") else None))
    return row

def run_cell(arm, seed, N, topology, visibility, severity, framing, backend, dbk, branches, judge=None, meta_extra=None, msg_file=None):
    t0 = time.time()
    cell = f"{arm}-s{seed}-N{N}-{topology}-{visibility}-sev{severity}-{framing}"
    meta = dict(arm=arm, cell=cell, seed=seed, N=N, topology=topology, visibility=visibility, severity=severity,
                framing=framing, **(meta_extra or {}))
    prefix = lg.new_game(N, topology, seed, ROUNDS, ACT, visibility, "posted")
    prefix.severity = severity
    lg.play(prefix, backend, until=FORK, framing=framing, seed=seed)
    x = lg.pick_target(prefix, "random")
    bseed = 31_001 + seed
    def play_branch(name, attacker, defense):
        b = lg.fork(prefix, bseed); b.defense = defense
        if attacker == "insider":
            lg.compromise(b, x)
        dv = dict(backend=dbk, budget=4, per_round=2, start=FORK + 1) if attacker == "d_evil" else None
        lg.play(b, backend, framing=framing, seed=bseed, d_evil=dv)
        return b
    states = pmap(play_branch, branches, len(branches))
    by = {br[0]: st for br, st in zip(branches, states)}
    rows = []
    for (name, attacker, defense), st in zip(branches, states):
        if st is None: continue
        r = branch_row(meta, name, attacker, defense, st, x if attacker == "insider" or True else None)
        clean = by.get(f"clean|{defense}") or by.get("clean|none")
        if clean is not None:
            ca, ce = lg.game_metrics(clean)["completion"], lg.game_metrics(clean, exclude=(x,))["completion"]
            r["attack_effect"] = (ce - r["completion"]) if attacker == "insider" else (ca - r["completion"])
            cn = by.get("clean|none")
            if cn is not None:
                r["net_damage"] = (lg.game_metrics(cn, exclude=(x,))["completion"] if attacker == "insider"
                                   else lg.game_metrics(cn)["completion"]) - r["completion"]
            r["defection_effect"] = r["defections"] - lg.betrayal_metrics(clean, FORK)["defections"]
        if arm == "E":   # her elicit_eval_belief defaults an unparseable reply to is_test=False; treat it as MISSING
            bel = lg.elicit_eval_belief(st, backend, framing=framing, seed=seed)
            parsed = []
            for b_ in bel:
                d_ = parse_json(b_["raw"])
                ok = isinstance(d_, dict) and isinstance(d_.get("is_test"), bool)
                jl("beliefs.jsonl", dict(meta, branch=name, attacker=attacker or "clean", agent=b_["agent"], parsed=int(ok),
                                         is_test=(d_["is_test"] if ok else None), confidence=(b_["confidence"] if ok else None),
                                         defected=int(any(d["actor"] == b_["agent"] and d["round"] > FORK for d in st.defections))))
                if ok: parsed.append(d_["is_test"])
            r["belief_parse_rate"] = len(parsed) / len(bel) if bel else None
            r["test_belief_rate"] = float(np.mean(parsed)) if parsed else None   # parsed answers only
        rows.append(r); jl("games.jsonl", r)
        if msg_file:
            ins.write_messages(os.path.join(OUT, msg_file), st, dict(arm=arm, cell=cell, branch=name, seed=seed, topology=topology))
    if judge is not None:   # instruments on attacked branches, vs the clean twin with the same defense
        jobs = [(name, attacker, defense) for (name, attacker, defense) in branches if attacker and by.get(name) is not None]
        def score(name, attacker, defense):
            clean = by.get(f"clean|{defense}") or by["clean|none"]
            ag = ins.score_game(by[name], clean, FORK, backend, judge, CACHE, offer=bool(seed % 2), framing=framing, seed=seed)
            for a in ag:
                jl("agents.jsonl", dict(meta, branch=name, attacker=attacker, defense=defense, **a))
            return len(ag)
        pmap(score, jobs, len(jobs))
    jl("cells.jsonl", dict(meta, secs=round(time.time() - t0, 1), branches=len(rows)))
    return rows

def arm_A():
    bk, db, jg = mk(QWEN, "A"), mk(QWEN, "A_d_evil"), mk(QWEN, "A_judge", temp=0.0, mnt=40)
    br = [(f"clean|{d}", None, d) for d in DEFS] + [(f"{a}|{d}", a, d) for a in ("d_evil", "insider") for d in DEFS]
    cells = [(s, t) for s in range(START["A"], SEEDS["A"]) for t in ("complete", "communities")]
    return pmap(lambda s, t: run_cell("A", s, 8, t, "private", 1, "assistant", bk, db, br, judge=jg, msg_file="messages.csv"), cells, PAR)
def arm_B():
    bk = mk(QWEN, "B")
    br = [("clean|none", None, "none"), ("insider|none", "insider", "none")]
    cells = [(s, v, sv) for s in range(SEEDS["B"]) for v in ("private", "public") for sv in (1, 2)]
    return pmap(lambda s, v, sv: run_cell("B", s, 8, "complete", v, sv, "assistant", bk, None, br, msg_file="messages_other_arms.csv"), cells, PAR)
def arm_C():
    bks = {n: mk(QWEN, f"C_N{n}") for n in SIZES_C}
    br = [("clean|none", None, "none"), ("insider|none", "insider", "none")]
    cells = [(s, n) for n in sorted(SIZES_C, reverse=True) for s in range(SEEDS["C"])]
    return pmap(lambda s, n: run_cell("C", s, n, "complete", "private", 1, "assistant", bks[n], None, br), cells, PAR)
def arm_D():
    bk, db, jg = mkmixed("D"), mk(QWEN, "D_d_evil"), mk(QWEN, "D_judge", temp=0.0, mnt=40)
    br = [(f"clean|{d}", None, d) for d in DEFS] + [(f"{a}|{d}", a, d) for a in ("d_evil", "insider") for d in DEFS]
    cells = [(s,) for s in range(START["D"], SEEDS["D"])]
    return pmap(lambda s: run_cell("D", s, 8, "complete", "private", 1, "assistant", bk, db, br, judge=jg, msg_file="messages_other_arms.csv"), cells, PAR)
def arm_E():
    bk = mk(QWEN, "E")
    br = [("clean|none", None, "none"), ("insider|none", "insider", "none")]
    cells = [(s, f) for s in range(SEEDS["E"]) for f in ("assistant", "assistant_test")]
    return pmap(lambda s, f: run_cell("E", s, 8, "complete", "private", 1, f, bk, None, br, msg_file="messages_other_arms.csv"), cells, PAR)

def arm_F():
    """Arm F: Adaption-platform mixed swarm (separate robustness arm; never pooled with Qwen-2.5 results).
    Agents on Adaption (key from ADAPTION_KEY_FILE only); D-Evil and the judge stay on OpenRouter Qwen-2.5-7B as in A/D."""
    import adaption_backend as adb
    specs = [tuple(x.split(":")) for x in os.environ.get("ARM_F_MODELS",
             "deepseek-v4-flash:none,gemma-4-26b-a4b-it:default,gemma-4-31b-it:default,qwen3.8-27b:none").split(",")]
    n = int(os.environ.get("ARM_F_N", str(2 * len(specs))))
    bk = adb.make_adaption_mixed(specs, arm="F")
    db, jg = mk(QWEN, "F_d_evil"), mk(QWEN, "F_judge", temp=0.0, mnt=40)
    log("arm F agents:", {i: bk.model_for(i) for i in range(n)})
    br = [(f"clean|{d}", None, d) for d in DEFS] + [(f"{a}|{d}", a, d) for a in ("d_evil", "insider") for d in DEFS]
    cells = [(sd,) for sd in range(START["F"], SEEDS["F"])]
    return pmap(lambda sd: run_cell("F", sd, n, "complete", "private", 1, "assistant", bk, db, br, judge=jg, msg_file="messages_arm_F.csv"), cells, PAR)

if __name__ == "__main__":
    bal = openrouter_credits()
    log("budget check (remaining credit):", {k: bal.get(k) for k in ("remaining", "limit", "usage") if k in bal} if isinstance(bal, dict) else bal)
    jl("events.jsonl", dict(ev="budget_check", t=time.time(), remaining=(bal or {}).get("remaining")))
    log("settings", dict(PILOT=PILOT, ARMS=ARMS, SEEDS=SEEDS, SIZES_C=SIZES_C, PAR=PAR, cap=os.environ.get("COST_CAP")))
    for arm in ARMS:
        t0, c0 = time.time(), COST["usd"]
        log("arm", arm, "start")
        jl("events.jsonl", dict(ev="arm_start", arm=arm, t=t0, usd=COST["usd"]))
        rows = {"A": arm_A, "B": arm_B, "C": arm_C, "D": arm_D, "E": arm_E, "F": arm_F}[arm]()
        _save_cost()
        jl("events.jsonl", dict(ev="arm_done", arm=arm, t=time.time(), secs=round(time.time() - t0, 1),
                                usd=COST["usd"], arm_usd=COST["usd"] - c0, by_arm=COST["by_arm"],
                                cells=sum(1 for r in rows if r is not None), cache_hits=CACHE.hits, cache_misses=CACHE.misses))
        log("arm", arm, "done", f"{time.time()-t0:.0f}s", f"${COST['usd']-c0:.4f}", "total", f"${COST['usd']:.4f}")
    _save_cost()
    try: _save_fixes()
    except Exception: pass
    log("FINAL", json.dumps({k: COST.get(k) for k in ("usd", "calls", "failed", "empty", "rate_limited_429", "adaption_usd", "adaption_calls", "adaption_failed")}))
